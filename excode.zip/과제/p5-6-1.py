#!/usr/bin/python3
import socket

host = ''
port = 11951
BUFF_SIZE = 128

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_address = (host, port)
sock.bind(server_address)
sock.listen(5)

while True:
    print('waiting for connection...')
    conn, client_address = sock.accept()
    print("connected from {} port {}".format(client_address[0], client_address[1]))

    while True:
        data = conn.recv(BUFF_SIZE)
        if not data:
            break
        print("echo message : {}".format(data.decode()))
        conn.sendall(data)

    print("disconnected from {} port {}".format(client_address[0], client_address[1]))
    conn.close()
sock.close()