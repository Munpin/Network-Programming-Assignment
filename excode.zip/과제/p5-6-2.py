#!/usr/bin/python3

import socket

host = ''
port = 11951
buff_size = 128
backlog = 5

conn_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = (host, port)
conn_sock.bind(server_address)

conn_sock.listen(backlog)

while True:
    print("waiting for requests...")
    data_sock, address = conn_sock.accept()
    print("echo request from {} port {}".format(address[0], address[1]))

    while True:
        message = data_sock.recv(buff_size)
        if message:
            print("recevied message : {}".format(message.decode()))
            data_sock.sendall(message)
        else:
            break
    print("connection closed from {} port {}".format(address[0], address[1]))
    data_sock.close()