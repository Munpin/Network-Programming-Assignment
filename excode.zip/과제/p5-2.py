import socket
import time

host = ''
port = 7070
BUFF_SIZE = 128

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_address = (host, port)
sock.bind(server_address)

while True:
    print('waiting for request...')
    message, client_address = sock.recvfrom(BUFF_SIZE)
    print("daytime request from {} port {}".format(client_address[0], client_address[1]))
    daytime = time.ctime()
    sock.sendto(daytime.encode(), client_address)
sock.close()