#!/usr/bin/python3

import socket

host = '203.250.133.88'
port = 8080
buff_size = 128
backlog = 5

conn_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_address = (host, port)
conn_sock.bind(server_address)

conn_sock.listen(backlog)

while True:
    print("waiting for requests...")
    data_sock, address = conn_sock.accept()
    print("echo request from {} port {}".format(address[0], address[1]))

    message = data_sock.recv(buff_size)
    if message:
        print("recevied message : {}".format(message.decode()))
        response = "HTTP/1.1 200 OK\r\n"
        response += "Content-Type: text/html\r\n"
        response += "Connection: close\r\n"
        response += "\r\n"
        response += "<html><body><h1>Hello, World!</h1></body></html>"
        data_sock.sendall(response.encode())
    data_sock.close()