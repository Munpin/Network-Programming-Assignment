year = input('년도를 입력하세요 : ')
if int(year) % 4 == 0 and int(year) % 100 != 0 or int(year) % 400 == 0:
    print(f'{year}년은 윤년입니다.')