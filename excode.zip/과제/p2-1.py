list1 = [1, 0, 1]
list2 = [1, 1, 2]
sum = 0

for i in range(3):
    sum += list1[i] * list2[i]
else:
    print(sum)