def main():
    while True:
        filename = input("읽을 파일 이름을 입력하세요 (그만하려면 q 입력): ")

        if filename == "q":
            print("프로그램을 종료합니다.")
            return
        try:
            f = open(filename, "r")
            lines = f.readlines()
            f.close()
            break
        except FileNotFoundError:
            print("파일을 찾을 수 없습니다: " + filename)
            print("다시 입력해주세요.\n")

    line_number = 1
    result_lines = []

    for line in lines:
        line = line.rstrip("\n")
        new_line = str(line_number) + ": " + line
        print(new_line)
        result_lines.append(new_line)
        line_number = line_number + 1

    save_filename = filename + ".sav"

    save_file = open(save_filename, "w")
    for new_line in result_lines:
        save_file.write(new_line + "\n")
    save_file.close()

    print("\n저장 완료: " + save_filename)