def calc(*argv, op):
  sum = 0
  for i in argv:
    if(op == '+'):
      sum += i
    elif(op == '*'):
      if(sum == 0):
        sum = i
        continue
      sum *= i
  return sum

ans1 = calc(1, 2, 3, op='+')
ans2 = calc(1, 2, op='*')
print(f"{ans1}, {ans2}")