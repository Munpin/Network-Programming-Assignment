import math

# 1) a=3, b=4, c=5 → 1/(1 + a/b + c)
a, b, c = 3, 4, 5
val1 = 1 / (1 + a/b + c)
print("1)", val1)  # 0.14814814814814814

# 2) a=1, b=1, c=-6 → 이차방정식 두 근
a, b, c = 1, 1, -6
d = b**2 - 4*a*c
x1 = (-b + math.sqrt(d)) / (2*a)
x2 = (-b - math.sqrt(d)) / (2*a)
print("2)", x1, x2)  # 2.0 -3.0

# 3) r=5 → 원의 면적
r = 5
area = math.pi * r**2
print("3)", area)  # 78.53981633974483

# 4) beta=2.0, g=3.2 → beta * e^(-g)
beta, g = 2.0, 3.2
val4 = beta * math.exp(-g)
print("4)", val4)  # 0.08152440795673242

# 5) x=0, mu=1.5, rho=2.0 → 정규분포 식
x, mu, rho = 0, 1.5, 2.0
val5 = (1 / (math.sqrt(2*math.pi) * rho)) * math.exp((x - mu)**2 / (2*rho**2))
print("5)", val5)  # 0.2642563263441777