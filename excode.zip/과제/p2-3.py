for i in range(100+1):
    if i % 2 == 0:
        print(f'{i}은 짝수입니다.')
    else:
        print(f'{i}은 홀수입니다.')